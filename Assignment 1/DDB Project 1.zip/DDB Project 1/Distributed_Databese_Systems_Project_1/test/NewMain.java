
import distributed_databese_systems_project_1.TestScenario1;

public class NewMain {

    public static void main(String[] args) {
        String a[] = {"distributed_databese_systems_project_1.LookupServer", "distributed_databese_systems_project_1.DatabaseServer", "distributed_databese_systems_project_1.Client"};
        TestScenario1.main(a);
    }

}
