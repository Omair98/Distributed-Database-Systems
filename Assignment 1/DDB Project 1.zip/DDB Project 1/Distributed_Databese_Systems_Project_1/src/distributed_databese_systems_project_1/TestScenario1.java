package distributed_databese_systems_project_1;

import java.util.*;

public class TestScenario1 {

    public static final int LUSPort = 10007;
    public static final int NumDatabaseServers = 2;
    public static final int DBSFirstPort = 50000;

    public static void main(String args[]) {
        System.out.println(args.length);
        if (args.length != 3) {
            System.out.println("usage: java TestScenario1 LookupServerClassName DatabaseServerClassName TransactionClassName");
            return;
        }
        Scanner in = new Scanner(System.in);
        LookupServerInterface lus = null;
        Vector<DatabaseServerInterface> vdbs = new Vector<>();

        try {
            /* initiation stage */
            Class lusClass = Class.forName(args[0]);
            lus = (LookupServerInterface) lusClass.newInstance();
            lus.startServer("127.0.0.1", LUSPort);

            Class dbsClass = Class.forName(args[1]);

            for (int i = 0; i < NumDatabaseServers; i++) {
                DatabaseServerInterface dbs = (DatabaseServerInterface) dbsClass.newInstance();
                vdbs.add(dbs);
                dbs.startServer("127.0.0.1", DBSFirstPort + i, "127.0.0.1", LUSPort);
            }


            /* do the actual testing */
            Class transClass = Class.forName(args[2]);

            TransactionInterface T1 = (TransactionInterface) transClass.newInstance();
            System.out.println("Begin1");
            String TID1 = T1.begin("127.0.0.1", DBSFirstPort);
            System.out.println("TID(T1)=" + TID1);

            System.out.println("Begin2");
            TransactionInterface T2 = (TransactionInterface) transClass.newInstance();
            String TID2 = T2.begin("127.0.0.1", DBSFirstPort + 1);
            System.out.println("TID(T2)=" + TID2);

            TransactionInterface T3 = (TransactionInterface) transClass.newInstance();
            System.out.println("Begin3");
            String TID3 = T3.begin("127.0.0.1", DBSFirstPort);
            System.out.println("TID(T3)=" + TID3);

            TransactionInterface T4 = (TransactionInterface) transClass.newInstance();
            System.out.println("Begin4");
            String TID4 = T4.begin("127.0.0.1", DBSFirstPort + 1);
            System.out.println("TID(T4)=" + TID4);

            System.out.println("Enter 5 values for horizontal fragmentation");
            for (int i = 1; i <= 5; i++) {
                System.out.println("Enter integer value " + i + " to add");
                int x = in.nextInt();
                if (x >= 100) {
                    System.out.println("Adding object \"sillyObject\" with initial value " + x + " on DB0...");
                    (vdbs.get(0)).addObject("sillyObject", x);
                    System.out.print("Setting sillyObject to " + x + " in T1...");
                    T1.setValue("sillyObject", x);
                    System.out.print("Commiting T1...");
                    T1.commit();
                    System.out.println("Reading sillyObject in T1: " + T1.getValue("sillyObject"));
                } else {
                    System.out.println("Adding object \"testobject\" with initial value " + x + " on DB0...");
                    (vdbs.get(0)).addObject("testobject", x);
                    System.out.print("Setting testobject to " + x + " in T2...");
                    T2.setValue("testobject", x);
                    System.out.print("Commiting T2...");
                    T2.commit();
                    System.out.println("Reading sillyObject in T1: " + T2.getValue("testobject"));
                }
                System.out.println("done");
            }

            System.out.println("Enter 5 values for vertical fragmentation");
            for (int i = 1; i <= 5; i++) {
                System.out.println("Enter integer value " + i + " to add");
                int x = in.nextInt();
                System.out.println("Enter operating city (Islamabad or Lahore)");
                String c = in.next();
                if (c.equalsIgnoreCase("Islamabad")) {
                    System.out.println("Adding object \"Obj1\" with initial value " + x + " and city: Islamabad on DB0...");
                    (vdbs.get(1)).addObject("Obj1", 100, "Islamabad");
                    T3.setValue("Obj1", x);
                    System.out.print("Commiting T3...");
                    T3.commit();
                    System.out.println("Reading Obj1 in T1: " + T3.getValue("Obj1") + "City: " + vdbs.get(1).getObject("Obj1"));
                } else {
                    System.out.println("Adding object \"Obj2\" with initial value " + x + " and city: Lahore on DB0...");
                    (vdbs.get(1)).addObject("Obj2", 100, "Lahore");
                    T3.setValue("Obj2", x);
                    System.out.print("Commiting T3...");
                    T3.commit();
                    System.out.println("Reading Obj2 in T1: " + T3.getValue("Obj2") + " and City: " + vdbs.get(1).getObject("Obj2"));
                }
            }

            /* termination stage */
            System.out.println("ending databases");
            for (int i = 0; i < NumDatabaseServers; i++) {
                DatabaseServerInterface dbs = vdbs.get(i);
                dbs.stopServer();
            }

            System.out.println("ending lookup");
            lus.stopServer();
        } catch (Exception e) {
            System.err.println("error: " + e);
        }
    }
}
