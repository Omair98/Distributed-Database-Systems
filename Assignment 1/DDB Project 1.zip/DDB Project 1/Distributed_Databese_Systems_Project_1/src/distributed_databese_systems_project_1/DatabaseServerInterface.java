package distributed_databese_systems_project_1;

/**
 *
 * @author super
 */
public interface DatabaseServerInterface {

    public void startServer(String myIP, int myPort, String LookupServerIP, int LookupServerPort);

    public void addObject(String objName, int initialValue);

    public void stopServer();

    public void addObject(String testobj, int i, String value);
    
    public String getObject(String testobj);
}
