package distributed_databese_systems_project_1;

/**
 *
 * @author super
 */

public interface LookupServerInterface {

    public void startServer(String myIP, int myPort);

    public void stopServer();
}
