package distributed_databese_systems_project_1;

/**
 *
 * @author super
 */
public class DatabaseObject {

    private int value;
    private String name;
    private String value2;
    private boolean modified;

    public DatabaseObject(int value) {
        this.value = value;
        this.modified = false;
    }

    public DatabaseObject(int value, String name) {
        this.value = value;
        this.name = name;
        this.modified = false;
    }

    public DatabaseObject(int value, String name, boolean mod) {
        this.value = value;
        this.name = name;
        this.modified = mod;
    }

    public DatabaseObject(int value, String name, String value2, boolean mod) {
        this.value = value;
        this.name = name;
        this.value2=value2;
        this.modified = mod;
    }

    public DatabaseObject(int value, String name, String value2) {
        this.value = value;
        this.name = name;
        this.value2 = value2;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int value) {
        this.value = value;
        this.modified = true;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isModified() {
        return modified;
    }

    /**
     * @return the value2
     */
    public String getValue2() {
        return value2;
    }

    /**
     * @param value2 the value2 to set
     */
    public void setValue2(String value2) {
        this.value2 = value2;
    }
}
